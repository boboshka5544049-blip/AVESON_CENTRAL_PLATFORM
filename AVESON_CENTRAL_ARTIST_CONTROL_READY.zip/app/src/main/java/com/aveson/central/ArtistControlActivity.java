package com.aveson.central;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ArtistControlActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(8,8,18), CARD = Color.rgb(20,20,35), BLUE = Color.rgb(60,130,255), TEXT = Color.WHITE, MUTED = Color.rgb(175,175,195);
    private LinearLayout root;
    @Override protected void onCreate(Bundle b){ super.onCreate(b); showRoom(); }
    private TextView title(String s,float z){ TextView t=new TextView(this); t.setText(s); t.setTextColor(TEXT); t.setTextSize(z); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,10,0,10); return t; }
    private TextView sub(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(MUTED); t.setTextSize(14); t.setPadding(0,0,0,20); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(15); b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); b.setAllCaps(false); b.setBackgroundColor(CARD); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,70); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b; }
    private void showRoom(){ ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(BG); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,32,28,32); scroll.addView(root); setContentView(scroll);
        TextView back=title("←  BACK TO AVESON CENTRAL",15); back.setTextColor(BLUE); back.setOnClickListener(v->finish()); root.addView(back); root.addView(title("AVESON ARTIST CONTROL",28)); root.addView(sub("Artist management • Release review • Content control")); root.addView(title("CONTROL CENTER",18));
        Button artists=btn("👤  ARTISTS\nManage AVESON artists"), releases=btn("🎵  RELEASE SUBMISSIONS\nReview songs submitted by artists"), videos=btn("🎬  VIDEO & CLIPS\nReview artist video submissions"), pending=btn("⏳  PENDING REVIEW\nContent waiting for admin decision"), approved=btn("✅  APPROVED\nApproved content ready for next stage"), rejected=btn("❌  REJECTED\nRejected submissions and reasons");
        root.addView(artists); root.addView(releases); root.addView(videos); root.addView(pending); root.addView(approved); root.addView(rejected);
        artists.setOnClickListener(v->message("ARTISTS","Artist management will appear here.\n\n• Artist profiles\n• Artist status\n• Releases\n• Video submissions")); releases.setOnClickListener(v->message("RELEASE SUBMISSIONS","Incoming music releases will appear here.\n\nAdmin can review and approve or reject them.")); videos.setOnClickListener(v->message("VIDEO & CLIPS","Artist video and clip submissions will appear here.")); pending.setOnClickListener(v->message("PENDING REVIEW","All submissions waiting for admin review.")); approved.setOnClickListener(v->message("APPROVED","Approved artist content will appear here.")); rejected.setOnClickListener(v->message("REJECTED","Rejected submissions will appear here.")); }
    private void message(String h,String s){ root.removeAllViews(); TextView back=title("←  BACK",15); back.setTextColor(BLUE); back.setOnClickListener(v->showRoom()); root.addView(back); root.addView(title(h,26)); root.addView(sub(s)); Button home=btn("🎤  ARTIST CONTROL HOME"); home.setOnClickListener(v->showRoom()); root.addView(home); }
}
