package com.aveson.central;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ArtistControlActivity extends AppCompatActivity {

    private static final int BG = Color.rgb(6, 7, 16);
    private static final int PANEL = Color.rgb(18, 19, 34);
    private static final int PANEL2 = Color.rgb(23, 24, 43);
    private static final int BORDER = Color.rgb(48, 45, 78);
    private static final int PURPLE = Color.rgb(156, 92, 255);
    private static final int BLUE = Color.rgb(76, 145, 255);
    private static final int CYAN = Color.rgb(62, 211, 222);
    private static final int GREEN = Color.rgb(72, 220, 151);
    private static final int RED = Color.rgb(255, 92, 120);
    private static final int TEXT = Color.rgb(248, 248, 255);
    private static final int MUTED = Color.rgb(160, 163, 185);

    private LinearLayout root;
    private ScrollView scroll;
    private LinearLayout content;
    private PopupWindow menuWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(3, 4, 10));
        showRoom();
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (strokeColor != Color.TRANSPARENT) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void gap(LinearLayout p, int h) {
        p.addView(new View(this), lp(-1, dp(h)));
    }

    private void showRoom() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        setContentView(root);

        // TOP BAR: BACK is no longer cramped into the title area.
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(8), dp(14), dp(8));
        top.setBackgroundColor(Color.rgb(9, 10, 21));
        root.addView(top, lp(-1, dp(66)));

        Button back = topButton("‹", 34, TEXT);
        back.setContentDescription("Back to AVESON CENTRAL");
        back.setOnClickListener(v -> finish());
        top.addView(back, lp(dp(52), dp(52)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView central = text("AVESON", 17, TEXT, true);
        TextView room = text("ARTIST CONTROL", 12, PURPLE, true);
        brand.addView(central);
        brand.addView(room);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(0, -1, 1f);
        brandLp.setMargins(dp(8), 0, dp(8), 0);
        top.addView(brand, brandLp);

        Button menu = topButton("☰", 25, TEXT);
        menu.setContentDescription("Menu");
        menu.setOnClickListener(v -> showMenu(menu));
        top.addView(menu, lp(dp(52), dp(52)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(content, lp(-1, -2));
        root.addView(scroll, lp(-1, 0));

        buildHomeContent();
    }

    private Button topButton(String label, int size, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(size);
        b.setTextColor(color);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(bg(PANEL2, 16, BORDER));
        return b;
    }

    private void buildHomeContent() {
        content.removeAllViews();

        TextView title = text("AVESON ARTIST CONTROL", 28, TEXT, true);
        title.setMaxLines(2);
        content.addView(title, lp(-1, -2));

        TextView sub = text("Artist management • Release review • Content control", 14, MUTED, false);
        sub.setPadding(0, dp(6), 0, 0);
        content.addView(sub, lp(-1, -2));
        gap(content, 22);

        TextView center = text("CONTROL CENTER", 20, TEXT, true);
        content.addView(center, lp(-1, -2));
        gap(content, 10);

        addCard("👤", "ARTISTS", "Artist profiles, IDs, status and account management", PURPLE,
                () -> info("ARTISTS", "Artist profiles\nArtist ID\nACTIVE / PENDING / SUSPENDED\nCountry • Releases • Videos • Earnings\nOpen Profile • Add / Invite Artist"));
        addCard("🎵", "RELEASE REVIEW", "Review music submitted by artists", BLUE,
                () -> info("RELEASE REVIEW", "Incoming song submissions\nMetadata review\nCover review\nApprove / Reject\nRelease notes and release date"));
        addCard("⏳", "PENDING REVIEW", "Content waiting for an admin decision", Color.rgb(244, 177, 74),
                () -> info("PENDING REVIEW", "All pending music and content\nReview queue\nSubmission status\nAdmin decision"));
        addCard("🎬", "VIDEO & CLIPS", "Separate video and clip control", CYAN,
                () -> info("VIDEO & CLIPS", "Video submissions\nClips\nProcessing status\nVideo analytics\nDistribution status"));
        addCard("✓", "APPROVED", "Approved content ready for the next stage", GREEN,
                () -> info("APPROVED", "Approved releases\nApproved videos\nReady for distribution"));
        addCard("×", "REJECTED", "Rejected submissions and review reasons", RED,
                () -> info("REJECTED", "Rejected content\nReview reasons\nCorrection / resubmission workflow"));
        addCard("◎", "DISTRIBUTION", "Delivery, territories and platform status", PURPLE,
                () -> info("DISTRIBUTION", "Platforms\nTerritories\nDelivery status\nRelease delivery and reports"));
        addCard("©", "RIGHTS & COPYRIGHT", "Ownership, publishing and splits", BLUE,
                () -> info("RIGHTS & COPYRIGHT", "Master rights\nPublishing\nCopyright ownership\nSplits\nSongwriters and contributors"));
        addCard("$", "ROYALTIES", "Earnings, statements and payouts", GREEN,
                () -> info("ROYALTIES", "Total earnings\nAvailable\nPending\nRelease earnings\nStatements\nPayout history"));
        addCard("▥", "ANALYTICS", "Artist, release and content insights", CYAN,
                () -> info("ANALYTICS", "Artist activity\nRelease performance\nVideo analytics\nAudience and territory insights"));
        addCard("⚙", "PARAMETERS", "Control settings and language options", PURPLE,
                () -> info("PARAMETERS", "Languages\nAVESON Audio Standard\nAVESON Standard Cover\nRelease settings\nSystem preferences"));
        addCard("▤", "RULES / TERMS", "AVESON rules, standards and legal guidance", BLUE,
                () -> info("RULES / TERMS", "Terms & Conditions\nSubmission rules\nAudio requirements\nCover requirements\nRights and ownership rules"));
        addCard("🔐", "SECURITY", "Access, admin security and protection", RED,
                () -> info("SECURITY", "Admin access\nSecurity controls\nSessions\nAccount protection"));
    }

    private void addCard(String icon, String title, String subtitle, int accent, final Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackground(bg(PANEL, 18, BORDER));
        card.setOnClickListener(v -> action.run());

        TextView iconView = text(icon, 23, accent, true);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView, lp(dp(48), dp(52)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        words.setPadding(dp(12), 0, dp(8), 0);
        words.addView(text(title, 15, TEXT, true));
        TextView desc = text(subtitle, 12, MUTED, false);
        desc.setPadding(0, dp(3), 0, 0);
        words.addView(desc);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0, -1, 1f);
        card.addView(words, wordsLp);

        TextView arrow = text("›", 28, accent, true);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, lp(dp(32), dp(52)));

        LinearLayout.LayoutParams cp = lp(-1, dp(82));
        cp.setMargins(0, dp(6), 0, dp(6));
        content.addView(card, cp);
    }

    private void showMenu(View anchor) {
        if (menuWindow != null && menuWindow.isShowing()) {
            menuWindow.dismiss();
            return;
        }

        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(14), dp(14), dp(14), dp(14));
        menu.setBackground(bg(Color.rgb(13, 14, 28), 22, Color.rgb(72, 58, 115)));

        TextView mh = text("AVESON CENTRAL", 19, TEXT, true);
        menu.addView(mh, lp(-1, dp(34)));
        TextView ms = text("CONTROL MENU", 11, PURPLE, true);
        menu.addView(ms, lp(-1, dp(26)));

        addMenuItem(menu, "⌂", "Home", this::buildHomeContent);
        addMenuItem(menu, "▥", "Analytics", () -> info("ANALYTICS", "Artist, release, video and audience analytics."));
        addMenuItem(menu, "$", "Royalty", () -> info("ROYALTY", "Earnings, statements and payout history."));
        addMenuItem(menu, "🔐", "Security", () -> info("SECURITY", "Admin access and security controls."));
        addMenuItem(menu, "◉", "Notifications", () -> info("NOTIFICATIONS", "System alerts and review notifications."));
        addMenuItem(menu, "◎", "Global", () -> info("GLOBAL", "Platforms, regions and global delivery controls."));
        addMenuItem(menu, "⚙", "Settings", () -> info("SETTINGS", "Preferences and configuration."));

        menuWindow = new PopupWindow(menu, dp(310), dp(520), true);
        menuWindow.setBackgroundDrawable(bg(Color.TRANSPARENT, 22, Color.TRANSPARENT));
        menuWindow.setOutsideTouchable(true);
        menuWindow.setElevation(dp(18));
        menuWindow.setOnDismissListener(() -> menuWindow = null);
        menuWindow.showAsDropDown(anchor, -dp(258), -dp(54));
    }

    private void addMenuItem(LinearLayout menu, String icon, String name, final Runnable action) {
        Button b = new Button(this);
        b.setText(icon + "   " + name);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setAllCaps(false);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setBackground(bg(PANEL2, 14, BORDER));
        b.setOnClickListener(v -> {
            if (menuWindow != null) menuWindow.dismiss();
            action.run();
        });
        LinearLayout.LayoutParams p = lp(-1, dp(50));
        p.setMargins(0, dp(4), 0, dp(4));
        menu.addView(b, p);
    }

    private void info(String heading, String body) {
        content.removeAllViews();

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        Button back = topButton("‹", 30, TEXT);
        back.setOnClickListener(v -> buildHomeContent());
        bar.addView(back, lp(dp(50), dp(50)));

        TextView h = text(heading, 22, TEXT, true);
        h.setPadding(dp(12), 0, 0, 0);
        bar.addView(h, lp(-1, dp(50)));
        content.addView(bar, lp(-1, dp(50)));
        gap(content, 16);

        TextView bodyText = text(body, 16, TEXT, false);
        bodyText.setLineSpacing(dp(5), 1f);
        bodyText.setPadding(dp(18), dp(18), dp(18), dp(18));
        bodyText.setBackground(bg(PANEL, 18, BORDER));
        content.addView(bodyText, lp(-1, -2));
        gap(content, 14);

        Button home = topButton("⌂   ARTIST CONTROL HOME", 14, TEXT);
        home.setOnClickListener(v -> buildHomeContent());
        content.addView(home, lp(-1, dp(54)));
    }
}
